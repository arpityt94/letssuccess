import fs from 'fs/promises';
import path from 'path';
import bcrypt from 'bcryptjs';
import { 
  User, 
  Package, 
  Course, 
  PaymentSubmission, 
  Commission, 
  WithdrawalRequest, 
  Notification, 
  Notice,
  SystemSettings
} from '../src/types.js';

const DATA_FILE = path.join(process.cwd(), 'database.json');

interface Schema {
  users: User[];
  passwords: Record<string, string>; // userId -> passwordHash
  packages: Package[];
  courses: Course[];
  payments: PaymentSubmission[];
  commissions: Commission[];
  withdrawals: WithdrawalRequest[];
  notifications: Notification[];
  notices: Notice[];
  settings?: SystemSettings;
}

const DEFAULT_PACKAGES: Package[] = [
  {
    id: 'startup',
    name: 'Startup Package',
    price: 1499,
    courses: ['Instagram Mastery', 'Video Editing', 'Beginner To Pro Training'],
    color: 'cyan',
    popularityText: 'Best for Beginners'
  },
  {
    id: 'foundation',
    name: 'Foundation Package',
    price: 2499,
    courses: ['Spoken English', 'Lead Generation', 'Fundamentals Of Online Business'],
    color: 'gold'
  },
  {
    id: 'branding',
    name: 'Branding Mastery Package',
    price: 4499,
    courses: ['Facebook Ads', 'YouTube Mastermind', 'Canva Mastery', 'Public Speaking'],
    color: 'emerald',
    popularityText: 'Most Popular'
  },
  {
    id: 'affiliate',
    name: 'Affiliate Package',
    price: 6999,
    courses: ['Website Designing', 'AI Mastermind', 'Freelancing', 'Google Ads'],
    color: 'rose'
  },
  {
    id: 'finance',
    name: 'Finance Premium Package',
    price: 9999,
    courses: ['Stock Market', 'Stock Trading'],
    color: 'violet',
    popularityText: 'Premium Value'
  }
];

const DEFAULT_COURSES: Course[] = [
  {
    id: 'c1',
    packageId: 'startup',
    title: 'Instagram Mastery',
    description: 'Learn how to grow your personal brand, design premium feeds, and generate organic leads through Instagram.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '4h 30m',
    lessonsCount: 12
  },
  {
    id: 'c2',
    packageId: 'startup',
    title: 'Video Editing',
    description: 'Master premium VN editor, CapCut, and basic Premiere Pro settings to design high-engagement reels.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '5h 15m',
    lessonsCount: 15
  },
  {
    id: 'c3',
    packageId: 'startup',
    title: 'Beginner To Pro Training',
    description: 'The standard blueprint to understanding affiliate strategies, landing tools, and establishing your positive mindset.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '3h 40m',
    lessonsCount: 10
  },
  {
    id: 'c4',
    packageId: 'foundation',
    title: 'Spoken English',
    description: 'Improve grammar, pronunciation, vocabulary, and start speaking English with absolute confidence in interviews.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '6h 10m',
    lessonsCount: 18
  },
  {
    id: 'c5',
    packageId: 'foundation',
    title: 'Lead Generation',
    description: 'Advanced funnels, automated landing pages, and magnetic hooks to source hundreds of targeted organic prospects.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '4h 50m',
    lessonsCount: 14
  },
  {
    id: 'c6',
    packageId: 'foundation',
    title: 'Fundamentals Of Online Business',
    description: 'The building blocks of online entrepreneurship, e-commerce flow, products pricing, and target market setups.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '5h 00m',
    lessonsCount: 11
  },
  {
    id: 'c7',
    packageId: 'branding',
    title: 'Facebook Ads Expert',
    description: 'Master premium advertising, custom conversions tracking, micro-budget testing, and retargeting ads.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '8h 25m',
    lessonsCount: 22
  },
  {
    id: 'c8',
    packageId: 'branding',
    title: 'YouTube Mastermind',
    description: 'Craft content calendars, set up channel tags, index algorithms, edit thumbnails, and scale views.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '7h 10m',
    lessonsCount: 20
  },
  {
    id: 'c9',
    packageId: 'branding',
    title: 'Canva Mastery',
    description: 'Design premium graphic posts, PDF templates, and video reels with Canva PRO features.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '4h 15m',
    lessonsCount: 12
  },
  {
    id: 'c10',
    packageId: 'branding',
    title: 'Public Speaking Secret',
    description: 'Body language, voice modulation, structuring presentations, and building high-impact connections.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '5h 30m',
    lessonsCount: 16
  },
  {
    id: 'c11',
    packageId: 'affiliate',
    title: 'Website Designing',
    description: 'Build premium responsive blogs, business sites, and landing pages with WordPress and Elementor.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '9h 15m',
    lessonsCount: 24
  },
  {
    id: 'c12',
    packageId: 'affiliate',
    title: 'AI Mastermind',
    description: 'Harness advanced ChatGPT prompting, Midjourney generation, and automations to 10x your speed.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1677442135136-760c813a743d?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '6h 40m',
    lessonsCount: 18
  },
  {
    id: 'c13',
    packageId: 'affiliate',
    title: 'Freelancing Strategy',
    description: 'Submit premium bids, optimize profiles on Upwork & Fiverr, close clients, and invoice securely.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '5h 45m',
    lessonsCount: 16
  },
  {
    id: 'c14',
    packageId: 'affiliate',
    title: 'Google Ads Masterclass',
    description: 'Run targeted Search, Video, and Display campaigns on Google to drive commercial results.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '7h 50m',
    lessonsCount: 19
  },
  {
    id: 'c15',
    packageId: 'finance',
    title: 'Stock Market Foundation',
    description: 'Discover value investing indicators, global economics effects, mutual funds, and standard IPO ratings.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '10h 00m',
    lessonsCount: 30
  },
  {
    id: 'c16',
    packageId: 'finance',
    title: 'Stock Trading Strategy',
    description: 'Ultimate intraday strategies, technical levels indicators, candlesticks chart tracking, and precise position sizing.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '11h 20m',
    lessonsCount: 35
  }
];

const DEFAULT_SETTINGS: SystemSettings = {
  logoText: "Let's Success",
  tagline: "Learn • Earn • Success",
  heroHeaderFirst: "Learn Skills.",
  heroHeaderHighlight: "Build Income.",
  heroHeaderLast: "Create Success.",
  heroSubtext: "“Learn Skills • Earn Commissions • Achieve Success”",
  heroParagraph: "Empowering digital entrepreneurs with practical video courses, Hindi recorded workshops, and a hyper-profitable direct referral commission ecosystem.",
  bannerImageUrl: "",
  maintenanceMode: false
};

let dbMemoryInstance: Schema | null = null;

async function getDB(): Promise<Schema> {
  if (dbMemoryInstance) {
    return dbMemoryInstance;
  }

  try {
    const rawData = await fs.readFile(DATA_FILE, 'utf-8');
    dbMemoryInstance = JSON.parse(rawData);
    if (!dbMemoryInstance!.settings) {
      dbMemoryInstance!.settings = { ...DEFAULT_SETTINGS };
      await saveDB();
    }
    return dbMemoryInstance!;
  } catch (err) {
    // Seed new database with Defaults & Admin
    const adminId = 'admin-root';
    const adminPasswordHash = await bcrypt.hash('adminpassword', 10);

    const initialData: Schema = {
      users: [
        {
          id: adminId,
          name: 'Marpit Admin',
          email: 'marpit792@gmail.com',
          role: 'admin',
          referralCode: 'SUCCESSADMIN',
          balance: 0,
          totalEarnings: 0,
          totalWithdrawn: 0,
          createdAt: new Date().toISOString()
        }
      ],
      passwords: {
        [adminId]: adminPasswordHash
      },
      packages: DEFAULT_PACKAGES,
      courses: DEFAULT_COURSES,
      payments: [],
      commissions: [],
      withdrawals: [],
      notifications: [
        {
          id: 'notif-welcome',
          title: "Welcome to Let's Success 2.0!",
          message: "Master digital skills, earn up to 80% direct commissions, and embark on your learning journey today! Learn • Earn • Success",
          createdAt: new Date().toISOString()
        }
      ],
      notices: [
        {
          id: 'n1',
          title: "🔥 Special Launch Bonus Notice",
          content: "Welcome to Let's Success 2.0! We have integrated a manual verification engine. Simply purchase any package, upload your snapshot + UTR, and your sponsor receives an instant 80% direct referral commission!",
          createdAt: new Date().toISOString(),
          isActive: true
        }
      ],
      settings: { ...DEFAULT_SETTINGS }
    };

    dbMemoryInstance = initialData;
    await saveDB();
    return dbMemoryInstance!;
  }
}

export async function saveDB(): Promise<void> {
  if (!dbMemoryInstance) return;
  await fs.writeFile(DATA_FILE, JSON.stringify(dbMemoryInstance, null, 2), 'utf-8');
}

// DATABASE TRANSACTIONS AND OPERATIONS
export const DB = {
  getUsers: async () => {
    const db = await getDB();
    return db.users;
  },
  
  findUserByEmail: async (email: string) => {
    const db = await getDB();
    return db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  },

  findUserById: async (id: string) => {
    const db = await getDB();
    return db.users.find(u => u.id === id);
  },

  findUserByReferralCode: async (code: string) => {
    const db = await getDB();
    const cleanCode = code.trim().toUpperCase();
    return db.users.find(u => u.referralCode === cleanCode);
  },

  getUserPasswordHash: async (userId: string) => {
    const db = await getDB();
    return db.passwords[userId];
  },

  createUser: async (user: User, passwordHash: string) => {
    const db = await getDB();
    db.users.push(user);
    db.passwords[user.id] = passwordHash;
    await saveDB();
    return user;
  },

  updateUser: async (userId: string, updates: Partial<User>) => {
    const db = await getDB();
    const index = db.users.findIndex(u => u.id === userId);
    if (index !== -1) {
      db.users[index] = { ...db.users[index], ...updates };
      await saveDB();
      return db.users[index];
    }
    return null;
  },

  updateUserPassword: async (userId: string, passwordHash: string) => {
    const db = await getDB();
    db.passwords[userId] = passwordHash;
    await saveDB();
    return true;
  },

  getPackages: async () => {
    const db = await getDB();
    return db.packages;
  },

  createPackage: async (pkg: Package) => {
    const db = await getDB();
    db.packages.push(pkg);
    await saveDB();
    return pkg;
  },

  getCourses: async () => {
    const db = await getDB();
    return db.courses;
  },

  createCourse: async (course: Course) => {
    const db = await getDB();
    db.courses.push(course);
    await saveDB();
    return course;
  },

  deleteCourse: async (courseId: string) => {
    const db = await getDB();
    db.courses = db.courses.filter(c => c.id !== courseId);
    await saveDB();
    return true;
  },

  getPayments: async () => {
    const db = await getDB();
    return db.payments;
  },

  createPayment: async (payment: PaymentSubmission) => {
    const db = await getDB();
    db.payments.push(payment);
    await saveDB();
    return payment;
  },

  updatePaymentStatus: async (paymentId: string, status: 'approved' | 'rejected', reason?: string) => {
    const db = await getDB();
    const payment = db.payments.find(p => p.id === paymentId);
    if (!payment) return null;

    payment.status = status;
    payment.verifiedAt = new Date().toISOString();
    if (reason) payment.rejectionReason = reason;

    if (status === 'approved') {
      // 1. Activate the package for this user
      const user = db.users.find(u => u.id === payment.userId);
      if (user) {
        user.activePackageId = payment.packageId;
        
        // 2. Distribute direct 80% commission if user was referred by a sponsor
        if (user.referredBy) {
          const sponsor = db.users.find(s => s.referralCode === user.referredBy);
          if (sponsor) {
            const commissionAmount = payment.price * 0.8;
            
            // Generate unique commission entry
            const commission: Commission = {
              id: `comm-${Math.random().toString(36).substr(2, 9)}`,
              userId: sponsor.id,
              userName: sponsor.name,
              referredUserId: user.id,
              referredUserName: user.name,
              packageId: payment.packageId,
              packageName: payment.packageName,
              amount: commissionAmount,
              status: 'approved',
              createdAt: new Date().toISOString()
            };

            db.commissions.push(commission);

            // Update sponsor balance & total earnings
            sponsor.balance += commissionAmount;
            sponsor.totalEarnings += commissionAmount;

            // Notify Sponsor
            db.notifications.push({
              id: `notif-${Math.random().toString(36).substr(2, 9)}`,
              userId: sponsor.id,
              title: "🎉 Direct Commission Received!",
              message: `Congratulations! Refferred member ${user.name} successfully joined with ${payment.packageName}. You received a direct referral commission of ₹${commissionAmount.toFixed(2)} (80%)!`,
              createdAt: new Date().toISOString()
            });
          }
        }

        // Notify Buyer
        db.notifications.push({
          id: `notif-${Math.random().toString(36).substr(2, 9)}`,
          userId: user.id,
          title: "💎 Package Activated!",
          message: `Your payment of ₹${payment.price} has been successfully verified! You now have unrestricted access to all courses in ${payment.packageName}. Complete modules to earn skill rewards!`,
          createdAt: new Date().toISOString()
        });
      }
    } else {
      // Payment Rejected: Notify Buyer
      db.notifications.push({
        id: `notif-${Math.random().toString(36).substr(2, 9)}`,
        userId: payment.userId,
        title: "❌ Payment Rejected",
        message: `Your payment verification submission for ${payment.packageName} was rejected. Reason: ${reason || 'Invalid screenshot or details'}. Please submit a valid payment screenshot & UPI transaction ID.`,
        createdAt: new Date().toISOString()
      });
    }

    await saveDB();
    return payment;
  },

  getCommissions: async () => {
    const db = await getDB();
    return db.commissions;
  },

  getWithdrawals: async () => {
    const db = await getDB();
    return db.withdrawals;
  },

  createWithdrawal: async (withdrawal: WithdrawalRequest) => {
    const db = await getDB();
    db.withdrawals.push(withdrawal);
    // Deduct from current user's available balance immediately upon submission
    const user = db.users.find(u => u.id === withdrawal.userId);
    if (user) {
      user.balance -= withdrawal.amount;
    }
    await saveDB();
    return withdrawal;
  },

  updateWithdrawalStatus: async (withdrawalId: string, status: 'approved' | 'rejected') => {
    const db = await getDB();
    const withdraw = db.withdrawals.find(w => w.id === withdrawalId);
    if (!withdraw) return null;

    withdraw.status = status;
    const user = db.users.find(u => u.id === withdraw.userId);

    if (status === 'approved') {
      if (user) {
        user.totalWithdrawn += withdraw.amount;
        
        db.notifications.push({
          id: `notif-${Math.random().toString(36).substr(2, 9)}`,
          userId: user.id,
          title: "💸 Withdrawal Request Disbursed",
          message: `Your withdrawal of ₹${withdraw.amount} via ${withdraw.method.toUpperCase()} has been approved and paid by admin! Standard bank clearance times apply.`,
          createdAt: new Date().toISOString()
        });
      }
    } else if (status === 'rejected') {
      // Return deducted balance back to user
      if (user) {
        user.balance += withdraw.amount;

        db.notifications.push({
          id: `notif-${Math.random().toString(36).substr(2, 9)}`,
          userId: user.id,
          title: "❌ Withdrawal Rejected & Refunded",
          message: `Your withdrawal request of ₹${withdraw.amount} was rejected by admin. The full amount has been refunded back to your wallet balance. Please check your bank information and submit again.`,
          createdAt: new Date().toISOString()
        });
      }
    }

    await saveDB();
    return withdraw;
  },

  getNotifications: async () => {
    const db = await getDB();
    return db.notifications;
  },

  createNotification: async (notif: Notification) => {
    const db = await getDB();
    db.notifications.push(notif);
    await saveDB();
    return notif;
  },

  getNotices: async () => {
    const db = await getDB();
    return db.notices;
  },

  createNotice: async (title: string, content: string) => {
    const db = await getDB();
    const notice: Notice = {
      id: `notice-${Math.random().toString(36).substr(2, 9)}`,
      title,
      content,
      createdAt: new Date().toISOString(),
      isActive: true
    };
    db.notices.push(notice);
    await saveDB();
    return notice;
  },

  deleteNotice: async (id: string) => {
    const db = await getDB();
    db.notices = db.notices.filter(n => n.id !== id);
    await saveDB();
    return true;
  },

  getSettings: async () => {
    const db = await getDB();
    if (!db.settings) {
      db.settings = { ...DEFAULT_SETTINGS };
      await saveDB();
    }
    return db.settings;
  },

  updateSettings: async (settings: Partial<SystemSettings>) => {
    const db = await getDB();
    if (!db.settings) {
      db.settings = { ...DEFAULT_SETTINGS };
    }
    db.settings = { ...db.settings, ...settings };
    await saveDB();
    return db.settings;
  }
};
